#pragma once

#include "GameObject.h"
#include "Player.h"
#include "Rail.h"

class CScene
{
public:
	CScene();
	virtual ~CScene();

	CPlayer						*m_pPlayer = NULL;
	
	virtual void BuildObjects();
	virtual void ReleaseObjects();

	virtual void CheckObjectByObjectCollisions();
		
	virtual void Update(float fElapsedTime);
	virtual void Render(HDC hDCFrameBuffer, CCamera *pCamera);

	virtual void OnProcessingMouseMessage(HWND hWnd, UINT nMessageID, WPARAM wParam, LPARAM lParam);
	virtual void OnProcessingKeyboardMessage(HWND hWnd, UINT nMessageID, WPARAM wParam, LPARAM lParam);
};

class CPlayerScene : public CScene
{
public:
	CPlayerScene();
	virtual ~CPlayerScene();

/* My Code */
public:
	void SetPitch(const float& pitch) { m_fPitch = pitch;}
	void SetYaw(const float& yaw) { m_fYaw = yaw; }
	void SetRoll(const float& roll) { m_fRoll = roll; }

private:
	vector<CRail*> m_vecRails;

	int m_iIndex = -1;

	float m_fAmount = 0.f;

	float m_fSpawnTime = 0.f;
	float m_fPitch = 0.f;
	float m_fYaw = 0.f;
	float m_fRoll = 0.f;


	XMFLOAT3 m_xmf3OldPos = { 0.f, 0.f, 0.f };

	bool m_isStartCheck = true;

	XMFLOAT3 m_xmf3PlayerStartPos = { 0.f, 0.f, 0.f };
public:
	virtual void Update(float fElapsedTime);
	virtual void Render(HDC hDCFrameBuffer, CCamera *pCamera);

public:
	void RidePlayerRail(float fElapsedTime);
	void BuildRail();
};

