#pragma once

/* My Class */

class CRail 
{
public:
	CRail();
	~CRail();

public:
	void SetRotation(const float& pitch, const float& yaw, const float& roll);
	void SetPosition(XMFLOAT3& xmf3Position);
	XMFLOAT3& GetPosition();
	XMFLOAT3& GetLookDir();

	const float& GetPitch() { return m_fPitch; }
	const float& GetYaw() { return m_fYaw; }
	const float& GetRoll() { return m_fRoll; }

public:
	void InitRail();
	int Update(float fElapsedTime);
	void Render(HDC hDCFrameBuffer, class CCamera *pCamera);
	void Release();

private:
	class CGameObject *m_pBoxLeft = nullptr;
	class CGameObject *m_pBoxRight = nullptr;
	class CGameObject *m_pPlane = nullptr;

	float m_fLifeTime = 0.f;
	float m_fPitch = 0.f;
	float m_fYaw = 0.f;
	float m_fRoll = 0.f;
};

