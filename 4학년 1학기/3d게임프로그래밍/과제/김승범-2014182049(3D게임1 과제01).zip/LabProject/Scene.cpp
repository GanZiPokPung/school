#include "stdafx.h"
#include "Scene.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
CScene::CScene()
{
}

CScene::~CScene()
{
}

void CScene::OnProcessingMouseMessage(HWND hWnd, UINT nMessageID, WPARAM wParam, LPARAM lParam)
{

}

void CScene::OnProcessingKeyboardMessage(HWND hWnd, UINT nMessageID, WPARAM wParam, LPARAM lParam)
{
}

void CScene::BuildObjects()
{
}

void CScene::ReleaseObjects()
{
}

void CScene::CheckObjectByObjectCollisions()
{
	
}

void CScene::Update(float fElapsedTime)
{
	
}

void CScene::Render(HDC hDCFrameBuffer, CCamera *pCamera)
{
	
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
CPlayerScene::CPlayerScene()
{
}

CPlayerScene::~CPlayerScene()
{
	for (auto& rail : m_vecRails)
	{
		rail->Release();
	}
	m_vecRails.clear();
}

void CPlayerScene::Update(float fElapsedTime)
{
	m_fSpawnTime += fElapsedTime;

	if (m_fSpawnTime >= 0.1f)
	{
		BuildRail();

		m_fSpawnTime = 0.f;
	}

	vector<CRail*>::iterator iter;
	for (iter = m_vecRails.begin(); iter != m_vecRails.end();)
	{
		if (-1 == (*iter)->Update(fElapsedTime))
		{
			(*iter)->Release();
			iter = m_vecRails.erase(iter);
			--m_iIndex;
		}
		else
			++iter;
	}

	RidePlayerRail(fElapsedTime);
}

void CPlayerScene::Render(HDC hDCFrameBuffer, CCamera * pCamera)
{
	for (const auto& rail : m_vecRails)
	{
		rail->Render(hDCFrameBuffer, pCamera);
	}
}

void CPlayerScene::RidePlayerRail(float fElapsedTime)
{
	if (m_vecRails.empty())
		return;

	if (-1 == m_iIndex)
		return;

	if (m_vecRails.size() == m_iIndex)
	{
		m_iIndex = 0;
		return;
	}

	if (m_fAmount > 1.f)
	{
		m_xmf3PlayerStartPos = m_vecRails[m_iIndex]->GetPosition();
		++m_iIndex;
		m_fAmount = 0.f;
		return;
	}

	m_pPlayer->SetRollPitchYaw(m_vecRails[m_iIndex]->GetPitch(),
		m_vecRails[m_iIndex]->GetRoll(),
		-m_vecRails[m_iIndex]->GetYaw());

	XMFLOAT3 xmfLerpedPos = XMFLOAT3(Lerp::lerp(m_xmf3PlayerStartPos.x, m_vecRails[m_iIndex]->GetPosition().x, m_fAmount),
							Lerp::lerp(m_xmf3PlayerStartPos.y, m_vecRails[m_iIndex]->GetPosition().y, m_fAmount),
							Lerp::lerp(m_xmf3PlayerStartPos.z, m_vecRails[m_iIndex]->GetPosition().z, m_fAmount));

	m_pPlayer->SetPosition(xmfLerpedPos.x, xmfLerpedPos.y, xmfLerpedPos.z);

	m_fAmount += fElapsedTime * 10.f;
}

void CPlayerScene::BuildRail()
{
	CRail* pRail = new CRail;
	pRail->InitRail();
	pRail->SetRotation(m_fPitch, m_fYaw, m_fRoll);

	XMFLOAT3 xmf3RailLookDir = pRail->GetLookDir();
	XMFLOAT3 xmf3MoveDistance = Vector3::ScalarProduct(xmf3RailLookDir, 5.f, false);
	XMFLOAT3 xmf3NewPosition = Vector3::Add(m_xmf3OldPos, xmf3MoveDistance);

	pRail->SetPosition(xmf3NewPosition);
	m_vecRails.emplace_back(pRail);
	m_xmf3OldPos = xmf3NewPosition;

	if (m_isStartCheck)
	{
		m_iIndex = 0;

		m_pPlayer->SetPosition(xmf3NewPosition.x, xmf3NewPosition.y, xmf3NewPosition.z);
		m_xmf3PlayerStartPos = xmf3NewPosition;

		m_pPlayer->Rotate(m_fPitch, m_fYaw, m_fRoll);
		m_isStartCheck = false;
	}
}
