#include "stdafx.h"
#include "Rail.h"
#include "GameObject.h"

CRail::CRail()
{
}

CRail::~CRail()
{
}

void CRail::SetRotation(const float & pitch, const float & yaw, const float & roll)
{
	m_pPlane->Rotate(pitch, yaw, roll);

	m_fPitch = pitch;
	m_fYaw = yaw;
	m_fRoll = roll;
}

void CRail::SetPosition(XMFLOAT3 & xmf3Position)
{
	m_pPlane->SetPosition(xmf3Position);
}

XMFLOAT3& CRail::GetPosition()
{
	return	m_pPlane->GetPosition();
}

XMFLOAT3 & CRail::GetLookDir()
{
	return  m_pPlane->GetLook();
}

void CRail::InitRail()
{
	CCubeMesh *pObjectCubeMesh = new CCubeMesh(2.f, 2.f, 2.f);
	CPlaneMesh *pObjectPlaneMesh = new CPlaneMesh(8.f, 5.f);
	
	if (!m_pPlane)
	{
		m_pPlane = new CGameObject();
		m_pPlane->SetMesh(pObjectPlaneMesh);
		m_pPlane->SetColor(RGB(0, 0, 0));
		m_pPlane->SetPosition(0.f, -1.f, 0.f);
	}

	if (!m_pBoxLeft)
	{
		m_pBoxLeft = new CGameObject();

		m_pBoxLeft->SetMesh(pObjectCubeMesh);
		m_pBoxLeft->SetPosition(-5.f, 1.f, 0.f);
		m_pBoxLeft->SetColor(RGB(0, 0, 0));	
	}

	if (!m_pBoxRight)
	{
		m_pBoxRight = new CGameObject();

		m_pBoxRight->SetMesh(pObjectCubeMesh);
		m_pBoxRight->SetPosition(+5.f, 1.f, 0.f);
		m_pBoxRight->SetColor(RGB(0, 0, 0));	
	}
}

int CRail::Update(float fElapsedTime)
{
	m_fLifeTime += fElapsedTime;

	if (m_fLifeTime >= 5.f)
	{
		m_fLifeTime = 0.f;
		return -1;
	}

	if (m_pPlane)
	{
		if (m_pBoxLeft)
			m_pBoxLeft->SetParentMatrix(m_pPlane->GetWorldMatrix());

		if (m_pBoxRight)
			m_pBoxRight->SetParentMatrix(m_pPlane->GetWorldMatrix());
	}

	return 0;
}

void CRail::Render(HDC hDCFrameBuffer, CCamera * pCamera)
{
	if (m_pPlane)
		m_pPlane->Render(hDCFrameBuffer, pCamera);
	
	if (m_pBoxLeft)
		m_pBoxLeft->Render(hDCFrameBuffer, pCamera);

	if (m_pBoxRight)
		m_pBoxRight->Render(hDCFrameBuffer, pCamera);
}

void CRail::Release()
{
	if (m_pPlane)
	{
		delete m_pPlane;
		m_pPlane = nullptr;
	}

	if (m_pBoxLeft)
	{
		delete m_pBoxLeft;
		m_pBoxLeft = nullptr;
	}

	if (m_pBoxRight)
	{
		delete m_pBoxRight;
		m_pBoxRight = nullptr;
	}

}
